import { BrowserCacheLocation, PublicClientApplication } from '@azure/msal-browser';

export const BC_SCOPES = ['https://api.businesscentral.dynamics.com/.default'];

export const msalInstance = new PublicClientApplication({
  auth: {
    clientId: 'e26581b7-b8fd-45cf-8610-b87570d1c4d9',
    authority: 'https://login.microsoftonline.com/6b99dd4b-9681-4414-8a12-1beeb67853f9',
    // Rollback al redirect già usato dalla registrazione BC
    redirectUri: 'https://businesscentral.dynamics.com/OAuthLanding.htm',
  },
  cache: {
    cacheLocation: BrowserCacheLocation.LocalStorage,
  },
  system: {
    allowPlatformBroker: true,
  },
});
