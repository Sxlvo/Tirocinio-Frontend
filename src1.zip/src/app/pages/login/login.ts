import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})
export class LoginComponent {
  errore = '';
  loading = false;

  constructor(
    private auth: AuthService,
    private router: Router,
    private route: ActivatedRoute,
  ) {}

  async loginMicrosoft(): Promise<void> {
    this.errore = '';
    this.loading = true;

    try {
      const ok = await this.auth.loginWithMicrosoft();

      if (!ok) {
        this.errore = 'Utente autenticato, ma non associato a un agente Business Central.';
        return;
      }

      const redirect = this.route.snapshot.queryParamMap.get('redirect') || '/';
      await this.router.navigateByUrl(redirect);
    } catch (error) {
      console.error('Errore durante il login Microsoft:', error);
      this.errore = 'Errore durante il login Microsoft';
    } finally {
      this.loading = false;
    }
  }
}
