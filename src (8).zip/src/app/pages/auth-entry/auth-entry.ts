import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-auth-entry',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './auth-entry.html',
  styleUrl: './auth-entry.scss',
})
export class AuthEntryComponent implements OnInit {
  popupMode = false;

  constructor(
    private auth: AuthService,
    private router: Router,
  ) {}

  async ngOnInit(): Promise<void> {
    const hasOAuthParams = typeof window !== 'undefined' && (
      window.location.search.includes('code=') ||
      window.location.search.includes('error=') ||
      window.location.hash.includes('code=') ||
      window.location.hash.includes('error=')
    );

    this.popupMode = !!window.opener || hasOAuthParams;

    if (this.popupMode) {
      return;
    }

    const ok = await this.auth.ensureSession();
    await this.router.navigateByUrl(ok ? '/home' : '/login');
  }
}
