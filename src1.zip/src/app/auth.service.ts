import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { InteractionRequiredAuthError, type AccountInfo } from '@azure/msal-browser';
import { BC_SCOPES, msalInstance } from './auth-config';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl =
    'https://api.businesscentral.dynamics.com/v2.0/6b99dd4b-9681-4414-8a12-1beeb67853f9/Sandbox_BC27/ODataV4/Company(Id=14fae42a-0299-f011-a7b1-6045bdc8dcac)/AgentLoginWS';

  private initialized = false;

  constructor(private http: HttpClient) {}

  private async initMsal(): Promise<void> {
    if (!this.initialized) {
      await msalInstance.initialize();
      this.initialized = true;
    }
  }

  private getCurrentAccount(): AccountInfo | null {
    let account = msalInstance.getActiveAccount();

    if (!account) {
      const accounts = msalInstance.getAllAccounts();
      if (accounts.length > 0) {
        account = accounts[0];
        msalInstance.setActiveAccount(account);
      }
    }

    return account;
  }

  private escapeODataString(value: string): string {
    return value.replace(/'/g, "''");
  }

  private async buildHeaders(): Promise<HttpHeaders> {
    const token = await this.getToken();

    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    });
  }

  private async loadBusinessCentralProfile(account: AccountInfo): Promise<boolean> {
    const email = account.username?.trim() ?? '';
    if (!email) {
      return false;
    }

    const safeEmail = this.escapeODataString(email);
    const findUrl = `${this.baseUrl}?$filter=E_Mail eq '${safeEmail}'`;
    const headers = await this.buildHeaders();

    const res = await firstValueFrom(this.http.get<any>(findUrl, { headers }));
    const agent = res?.value?.[0];

    if (!agent?.Code) {
      return false;
    }

    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('userEmail', email);
    localStorage.setItem('userName', (agent.Name ?? account.name ?? email).trim());
    localStorage.setItem('agentCode', agent.Code);

    return true;
  }

  async loginWithMicrosoft(): Promise<boolean> {
    await this.initMsal();

    const loginResponse = await msalInstance.loginPopup({
      scopes: BC_SCOPES,
    });

    if (!loginResponse.account) {
      return false;
    }

    msalInstance.setActiveAccount(loginResponse.account);

    await this.getToken();
    return this.loadBusinessCentralProfile(loginResponse.account);
  }

  async ensureSession(): Promise<boolean> {
    await this.initMsal();

    const account = this.getCurrentAccount();
    if (!account) {
      return false;
    }

    try {
      await msalInstance.acquireTokenSilent({
        account,
        scopes: BC_SCOPES,
      });

      if (!localStorage.getItem('agentCode')) {
        return await this.loadBusinessCentralProfile(account);
      }

      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('userEmail', account.username ?? '');
      return true;
    } catch {
      return false;
    }
  }

  async getToken(): Promise<string> {
    await this.initMsal();

    let account = this.getCurrentAccount();

    if (!account) {
      const loginResponse = await msalInstance.loginPopup({
        scopes: BC_SCOPES,
      });

      if (!loginResponse.account) {
        throw new Error('Account Microsoft non disponibile dopo il login.');
      }

      account = loginResponse.account;
      msalInstance.setActiveAccount(account);
    }

    try {
      const response = await msalInstance.acquireTokenSilent({
        account,
        scopes: BC_SCOPES,
      });

      return response.accessToken;
    } catch (error) {
      if (error instanceof InteractionRequiredAuthError) {
        const response = await msalInstance.acquireTokenPopup({
          account,
          scopes: BC_SCOPES,
        });

        if (response.account) {
          msalInstance.setActiveAccount(response.account);
        }

        return response.accessToken;
      }

      throw error;
    }
  }

  logout(): void {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userName');
    localStorage.removeItem('agentCode');

    const account = this.getCurrentAccount();
    if (account) {
      void msalInstance.logoutPopup({
        account,
        mainWindowRedirectUri: '/login',
      });
    }
  }

  isLoggedIn(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  getUserName(): string {
    return localStorage.getItem('userName') || '';
  }
}
